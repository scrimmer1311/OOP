/*
 * Rectangle.h
 *
 *  Created on: 5 апр. 2023 г.
 *      Author: george
 */

#ifndef RECTANGLE_H_
#define RECTANGLE_H_

#include "Figure.hpp"

class Rectangle: virtual public Figure {
	double a; // Size of side [m]
public:
	Rectangle() = delete;
	Rectangle(double);
	double GetSide();
	double perimeter() override;
	double area() override;
};

#endif /* RECTANGLE_H_ */
