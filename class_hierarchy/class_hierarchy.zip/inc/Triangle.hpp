/*
 * Traingle.hpp
 *
 *  Created on: 5 апр. 2023 г.
 *      Author: george
 */

#ifndef TRIANGLE_HPP_
#define TRIANGLE_HPP_

#include "Figure.hpp"

class Triangle: virtual public Figure {
	double a,b,c; // Sides [m]
public:
	Triangle() = delete; //
	Triangle(double, double, double);
	double GetSide(int);
	double perimeter() override;
	double area() override;
};

#endif /* TRIANGLE_HPP_ */
